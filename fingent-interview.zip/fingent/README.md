# Project name
***
Build an application that can be used to generate Invoices
#Software Used
PHP, HTML, Javascript, CSS
#Software needed
LINUX , Windows
#Instruction 
upload this fie to your server
Eg:- if you using XAMPP
upload file to xamp\server\htdocs\

Run With Local Host