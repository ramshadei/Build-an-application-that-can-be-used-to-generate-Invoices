<?php 
session_start();

class CartPage
{
	public $status = "";
	public $productID = "";
	public  $subTlWithtaxArray="" ;
	public $subTotalArray = "";
	
function sessionCart()
{
 if(!empty($_SESSION['shoppingCart']))
 {
	 $sessionArray = $_SESSION['shoppingCart'];
	
	foreach($sessionArray as $singleItems)
	{
		
		$itemName =  $singleItems['name'];
		$singlePrice = $singleItems['price'];
		$quantity = $singleItems['quantity'];
		$tax = $singleItems['tax'];
		
		$total  = $singlePrice*$quantity;
		$taxAmt = $total*($tax/100);
		$grandTotal = $total+$taxAmt;
		
		$itemArray[] = array($itemName, $grandTotal);
		
		$subTotalArray[] = $total;
		
		$subTlWithtaxArray[] = $grandTotal;
		
	
		
		
		
		
		
	
		//print_r($totalArray)."<br>";
	
	}
		//print_r($subTotalArray);
		$itemArray = $itemArray;
		is_array($subTlWithtaxArray)  ?  $totalCart = count($subTlWithtaxArray) : $totalCart = "";
		is_array($subTotalArray) ? $subTotal = array_sum($subTotalArray) : $subTotal = "" ;
		is_array($subTlWithtaxArray) ? $subTotalTax = array_sum($subTlWithtaxArray) : $subTotalTax = "";	
}
}
	
	
	public function addCart()
	{
		global $totalCart;
		global $subTotal;
		global $itemArray;
		global $subTotalTax;
		global $discount;
		global $finalAmt;
		
		if(isset($_POST["add"]))
			{
	$productID = $_POST['productID'];
	$item = $_POST['itemName'];
	$quantity = $_POST['quantity'];
	$price =$_POST['price'];
	$tax = $_POST['tax'];
	
	$cartArray = array($productID=>array(
						'name' => $item,
						'productId' =>$productID,
						'quantity' => $quantity,
						'price' => $price,
						'tax' => $tax));
						
if(empty($_SESSION['shoppingCart'])){
	$_SESSION['shoppingCart'] = $cartArray;
	$status = "<div>Product Added</div>";

}else{
	$arraykey = array_keys($_SESSION['shoppingCart']);
	if(in_array($productID,$arraykey)) {
		$_SESSION['shoppingCart'] = array_merge($_SESSION['shoppingCart'], $cartArray);
		$status = "<div>Product Added</div>";
	}else{
		$_SESSION['shoppingCart'] = array_merge($_SESSION['shoppingCart'], $cartArray);
		$status = "<div>Product Added</div>";	
	}
}
	//print_r($_SESSION['shoppingCart']);
	$sessionArray = $_SESSION['shoppingCart'];
	
	foreach($sessionArray as $singleItems)
	{
		
		$itemName =  $singleItems['name'];
		$singlePrice = $singleItems['price'];
		$quantity = $singleItems['quantity'];
		$tax = $singleItems['tax'];
		
		$total  = $singlePrice*$quantity;
		$taxAmt = $total*($tax/100);
		$grandTotal = $total+$taxAmt;
		
		$itemArray[] = array($itemName, $grandTotal);
		
		$subTotalArray[] = $total;
		
		$subTlWithtaxArray[] = $grandTotal;
		
	
		
		
		
		
		
	
		//print_r($totalArray)."<br>";
	
	}
		//print_r($subTotalArray);
		$itemArray = $itemArray;
		is_array($subTlWithtaxArray)  ?  $totalCart = count($subTlWithtaxArray) : $totalCart = "";
		is_array($subTotalArray) ? $subTotal = array_sum($subTotalArray) : $subTotal = "" ;
		is_array($subTlWithtaxArray) ? $subTotalTax = array_sum($subTlWithtaxArray) : $subTotalTax = "";
		$discount = $subTotalTax*(5/100);
		$finalAmt = $subTotalTax-$discount;
		
}
	}
	function remooveCart()
	{
		global $totalCart;
		global $subTotal;
		global $itemArray;
		global $subTotalTax;
		global $discount;
		global $finalAmt;
		
			$subTotalArray[] = array();
			$subTlWithtaxArray= array();
			
		if(isset($_POST['remoove'])){
	$productID = $_POST['productID'];
	unset($_SESSION['shoppingCart'][$productID]);
$sessionArray = $_SESSION['shoppingCart'];
	
	foreach($sessionArray as $singleItems)
	{
		
		$itemName =  $singleItems['name'];
		$singlePrice = $singleItems['price'];
		$quantity = $singleItems['quantity'];
		$tax = $singleItems['tax'];
		
		$total  = $singlePrice*$quantity;
		$taxAmt = $total*($tax/100);
		$grandTotal = $total+$taxAmt;
		
		$itemArray[] = array($itemName, $grandTotal);
		
		$subTotalArray[] = $total;
		
		$subTlWithtaxArray[] = $grandTotal;
		
	
		
		
		
		
		
	
		//print_r($totalArray)."<br>";
	
	}
	
		$itemArray = $itemArray;
		is_array($subTlWithtaxArray)  ?  $totalCart = count($subTlWithtaxArray) : $totalCart = "";
		is_array($subTotalArray) ? $subTotal = array_sum($subTotalArray) : $subTotal = "" ;
		is_array($subTlWithtaxArray) ? $subTotalTax = array_sum($subTlWithtaxArray) : $subTotalTax = "";
		$discount = $subTotalTax*(5/100);
		$finalAmt = $subTotalTax-$discount;
	
}
	}
}