<?php
include("functions.php");
$status = "";
$totalCart= "";
$subTotal="";
$subTotalTax  = "";
$finalAmt="";
$discount="";
$objCart = new CartPage();

if(isset($_POST["add"]))
{
	
$objCart->addCart();
//print_r($itemArray);
}
if(isset($_POST['remoove'])){
$objCart->remooveCart();

}

	

?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

<link href="dist/css/bootstrap.min.css" rel="stylesheet">

    
 
  </head>
  <body class="bg-light">
    
<div class="container">
  <main>
  
<div class="col-12 pt-5"><h1>Shopping Cart </h1></div>
        <div>
        <div class="col-5 float-end">
        <div class="row col-12">
      <div class="" id="divToPrint">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Your cart</span>
          <span class="badge bg-primary rounded-pill"><?php  echo  $totalCart; ?></span>
        </h4>
        <ul class="list-group mb-3">
        
        <?php if(!empty($itemArray)) { foreach ($itemArray as $items) {  ?>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0"><?php echo $items[0]; ?></h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted"><?php echo $items[1]; ?></span>
          </li>
          
          
          <?php }
		   } ?>
          
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Subtotal Without Tax</h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted"><?php echo $subTotal; ?>$ </span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Subtotal With Tax</h6>
              <small class="text-muted">Brief description</small>
            </div>
            <span class="text-muted"><?php echo $subTotalTax;?>$</span>
          </li>
          <li class="list-group-item d-flex justify-content-between bg-light">
            <div class="text-success">
              <h6 class="my-0">Discount</h6>
              <small>5%</small>
            </div>
            <span class="text-success">−$<?php echo $discount; ?></span>
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Total (USD)</span>
            <strong>$<?php echo $finalAmt; ?></strong>
          </li>
        </ul>

        <form class="card p-2">
          <div class="input-group">
            
            <button type="submit" class="btn btn-secondary" onclick="printDiv('printableArea')" >Print Invoice</button>
          </div>
        </form>
      </div>
      </div>
      </div>
      <div class="row col-7 mb-5 float-start">
      <div class="col-4 float-start"> <img src="img/1.jpg"></div>
       <div class="col-8">
       <form name="cart" method="post">
       <input type="hidden" value="001" name="productID">
       <p class="col-3 float-start">Item Name:</p><p> <input name="itemName" type="text" value="First Product" readonly></p> 
        <p class="col-3 float-start">Quantity:</p><p> <input name="quantity" type="number" value="1"></p>
        <p class="col-3 float-start">Unit Price:</p><p><input name="price" type="text" value="25" readonly> </p>
        <p class="col-3 float-start">Tax:</p><p><input name="tax" type="text" value="1" readonly>% </p>
        <p><input type="submit" name="add" value="ADD TO CART"> <input type="submit" name="remoove" value="REMOOVE"></p>
        </form>
        <p> <?php echo $status; ?></p>
       </div>
      </div>
    <div class="row col-7  mb-5 float-start">
      <div class="col-4 float-start"> <img src="img/2.jpg"></div>
       <div class="col-8">
       <form name="cart" method="post">
       <input type="hidden" value="002" name="productID">
       <p class="col-3 float-start">Item Name:</p><p> <input name="itemName" type="text" value="Second  Product" readonly></p> 
        <p class="col-3 float-start">Quantity:</p><p> <input name="quantity" type="number" value="1"></p>
        <p class="col-3 float-start">Unit Price:</p><p><input name="price" type="text" value="52" readonly> </p>
        <p class="col-3 float-start">Tax:</p><p><input name="tax" type="text" value="5" readonly>% </p>
        <p><input type="submit" name="add" value="ADD TO CART"> <input type="submit" name="remoove" value="REMOOVE"></p>
        </form>
        <p> <?php echo $status; ?></p>
       </div>
      </div><div class="row col-7  mb-5 float-start">
      <div class="col-4 float-start"> <img src="img/3.jpg"></div>
       <div class="col-8">
       <form name="cart" method="post">
       <input type="hidden" value="003" name="productID">
       <p class="col-3 float-start">Item Name:</p><p> <input name="itemName" type="text" value="Third Product" readonly></p> 
        <p class="col-3 float-start">Quantity:</p><p> <input name="quantity" type="number" value="1"></p>
        <p class="col-3 float-start">Unit Price:</p><p><input name="price" type="text" value="79" readonly> </p>
        <p class="col-3 float-start">Tax:</p><p><input name="tax" type="text" value="0" readonly>% </p>
        <p><input type="submit" name="add" value="ADD TO CART"> <input type="submit" name="remoove" value="REMOOVE"></p>
        </form>
        <p> <?php echo $status; ?></p>
       </div>
      </div><div class="row col-7  mb-5 float-start">
      <div class="col-4 float-start"> <img src="img/4.jpg"></div>
       <div class="col-8">
       <form name="cart" method="post">
       <input type="hidden" value="004" name="productID">
       <p class="col-3 float-start">Item Name:</p><p> <input name="itemName" type="text" value="Four Product" readonly></p> 
        <p class="col-3 float-start">Quantity:</p><p> <input name="quantity" type="number" value="1"></p>
        <p class="col-3 float-start">Unit Price:</p><p><input name="price" type="text" value="15" readonly> </p>
        <p class="col-3 float-start">Tax:</p><p><input name="tax" type="text" value="10" readonly>% </p>
        <p><input type="submit" name="add" value="ADD TO CART"> <input type="submit" name="remoove" value="REMOOVE"></p>
        </form>
        <p> <?php echo $status; ?></p>
       </div>
      </div>
</div>

  </main>

  
</div>


   
 
  </body>
  <script type="text/javascript">     
 function printDiv(divName) {
     var printContents = document.getElementById('divToPrint').innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
 </script>
</html>

